-- MOAIAction
MOAIAction = { }
MOAIAction.EVENT_STOP = true

function MOAIAction.addChild( ) end
function MOAIAction.clear( ) end
function MOAIAction.isActive( ) end
function MOAIAction.isBusy( ) end
function MOAIAction.isDone( ) end
function MOAIAction.start( ) end
function MOAIAction.stop( ) end
function MOAIAction.throttle( ) end

-- MOAIActionMgr
MOAIActionMgr = { }

function MOAIActionMgr.getRoot( ) end
function MOAIActionMgr.setProfilingEnabled( ) end
function MOAIActionMgr.setRoot( ) end
function MOAIActionMgr.setThreadInfoEnabled( ) end

-- MOAIAnim
MOAIAnim = { }

function MOAIAnim.apply( ) end
function MOAIAnim.getLength( ) end
function MOAIAnim.getTime( ) end
function MOAIAnim.getTimesExecuted( ) end
function MOAIAnim.reserveLinks( ) end
function MOAIAnim.setCurve( ) end
function MOAIAnim.setLink( ) end
function MOAIAnim.setMode( ) end
function MOAIAnim.setSpan( ) end
function MOAIAnim.setSpeed( ) end
function MOAIAnim.setTime( ) end

-- MOAIAnimCurve
MOAIAnimCurve = { }
MOAIAnimCurve.ATTR_TIME = true
MOAIAnimCurve.ATTR_VALUE = true

function MOAIAnimCurve.getLength( ) end
function MOAIAnimCurve.getValueAtTime( ) end
function MOAIAnimCurve.reserveKeys( ) end
function MOAIAnimCurve.setKey( ) end

-- MOAIApp
MOAIApp = { }
MOAIApp.ERROR = true
MOAIApp.DID_REGISTER = true
MOAIApp.REMOTE_NOTIFICATION = true
MOAIApp.REMOTE_NOTIFICATION_NONE = true
MOAIApp.REMOTE_NOTIFICATION_BADGE = true
MOAIApp.REMOTE_NOTIFICATION_SOUND = true
MOAIApp.REMOTE_NOTIFICATION_ALERT = true

-- MOAIBox2DArbiter
MOAIBox2DArbiter = { }
MOAIBox2DArbiter.BEGIN = true
MOAIBox2DArbiter.END = true
MOAIBox2DArbiter.POST_SOLVE = true
MOAIBox2DArbiter.PRE_SOLVE = true
MOAIBox2DArbiter.ALL = true

function MOAIBox2DArbiter.getContactNormal( ) end
function MOAIBox2DArbiter.getNormalImpulse( ) end
function MOAIBox2DArbiter.getTangentImpulse( ) end
function MOAIBox2DArbiter.setContactEnabled( ) end

-- MOAIBox2DBody
MOAIBox2DBody = { }
MOAIBox2DBody.DYNAMIC = true
MOAIBox2DBody.KINEMATIC = true
MOAIBox2DBody.STATIC = true

function MOAIBox2DBody.addCircle( ) end
function MOAIBox2DBody.addEdges( ) end
function MOAIBox2DBody.addPolygon( ) end
function MOAIBox2DBody.addRect( ) end
function MOAIBox2DBody.applyAngularImpulse( ) end
function MOAIBox2DBody.applyForce( ) end
function MOAIBox2DBody.applyLinearImpulse( ) end
function MOAIBox2DBody.applyTorque( ) end
function MOAIBox2DBody.destroy( ) end
function MOAIBox2DBody.getAngle( ) end
function MOAIBox2DBody.getAngularVelocity( ) end
function MOAIBox2DBody.getInertia( ) end
function MOAIBox2DBody.getLinearVelocity( ) end
function MOAIBox2DBody.getLocalCenter( ) end
function MOAIBox2DBody.getMass( ) end
function MOAIBox2DBody.getPosition( ) end
function MOAIBox2DBody.getWorldCenter( ) end
function MOAIBox2DBody.getWorldDir( ) end
function MOAIBox2DBody.getWorldLoc( ) end
function MOAIBox2DBody.getWorldRot( ) end
function MOAIBox2DBody.getWorldScl( ) end
function MOAIBox2DBody.isActive( ) end
function MOAIBox2DBody.isAwake( ) end
function MOAIBox2DBody.isBullet( ) end
function MOAIBox2DBody.isFixedRotation( ) end
function MOAIBox2DBody.resetMassData( ) end
function MOAIBox2DBody.setActive( ) end
function MOAIBox2DBody.setAngularDamping( ) end
function MOAIBox2DBody.setAngularVelocity( ) end
function MOAIBox2DBody.setAwake( ) end
function MOAIBox2DBody.setBullet( ) end
function MOAIBox2DBody.setFixedRotation( ) end
function MOAIBox2DBody.setLinearDamping( ) end
function MOAIBox2DBody.setLinearVelocity( ) end
function MOAIBox2DBody.setMassData( ) end
function MOAIBox2DBody.setTransform( ) end

-- MOAIBox2DDistanceJoint
MOAIBox2DDistanceJoint = { }

function MOAIBox2DDistanceJoint.destroy( ) end
function MOAIBox2DDistanceJoint.getAnchorA( ) end
function MOAIBox2DDistanceJoint.getAnchorB( ) end
function MOAIBox2DDistanceJoint.getBodyA( ) end
function MOAIBox2DDistanceJoint.getBodyB( ) end
function MOAIBox2DDistanceJoint.getDampingRatio( ) end
function MOAIBox2DDistanceJoint.getFrequency( ) end
function MOAIBox2DDistanceJoint.getLength( ) end
function MOAIBox2DDistanceJoint.getReactionForce( ) end
function MOAIBox2DDistanceJoint.getReactionTorque( ) end
function MOAIBox2DDistanceJoint.setDampingRatio( ) end
function MOAIBox2DDistanceJoint.setFrequency( ) end
function MOAIBox2DDistanceJoint.setLength( ) end

-- MOAIBox2DFixture
MOAIBox2DFixture = { }

function MOAIBox2DFixture.destroy( ) end
function MOAIBox2DFixture.getBody( ) end
function MOAIBox2DFixture.setCollisionHandler( ) end
function MOAIBox2DFixture.setDensity( ) end
function MOAIBox2DFixture.setFilter( ) end
function MOAIBox2DFixture.setFriction( ) end
function MOAIBox2DFixture.setRestitution( ) end
function MOAIBox2DFixture.setSensor( ) end

-- MOAIBox2DFrictionJoint
MOAIBox2DFrictionJoint = { }

function MOAIBox2DFrictionJoint.destroy( ) end
function MOAIBox2DFrictionJoint.getAnchorA( ) end
function MOAIBox2DFrictionJoint.getAnchorB( ) end
function MOAIBox2DFrictionJoint.getBodyA( ) end
function MOAIBox2DFrictionJoint.getBodyB( ) end
function MOAIBox2DFrictionJoint.getMaxForce( ) end
function MOAIBox2DFrictionJoint.getMaxTorque( ) end
function MOAIBox2DFrictionJoint.getReactionForce( ) end
function MOAIBox2DFrictionJoint.getReactionTorque( ) end
function MOAIBox2DFrictionJoint.setMaxForce( ) end
function MOAIBox2DFrictionJoint.setMaxTorque( ) end

-- MOAIBox2DGearJoint
MOAIBox2DGearJoint = { }

function MOAIBox2DGearJoint.destroy( ) end
function MOAIBox2DGearJoint.getAnchorA( ) end
function MOAIBox2DGearJoint.getAnchorB( ) end
function MOAIBox2DGearJoint.getBodyA( ) end
function MOAIBox2DGearJoint.getBodyB( ) end
function MOAIBox2DGearJoint.getJointA( ) end
function MOAIBox2DGearJoint.getJointB( ) end
function MOAIBox2DGearJoint.getRatio( ) end
function MOAIBox2DGearJoint.getReactionForce( ) end
function MOAIBox2DGearJoint.getReactionTorque( ) end
function MOAIBox2DGearJoint.setRatio( ) end

-- MOAIBox2DJoint
MOAIBox2DJoint = { }

function MOAIBox2DJoint.destroy( ) end
function MOAIBox2DJoint.getAnchorA( ) end
function MOAIBox2DJoint.getAnchorB( ) end
function MOAIBox2DJoint.getBodyA( ) end
function MOAIBox2DJoint.getBodyB( ) end
function MOAIBox2DJoint.getReactionForce( ) end
function MOAIBox2DJoint.getReactionTorque( ) end

-- MOAIBox2DMouseJoint
MOAIBox2DMouseJoint = { }

function MOAIBox2DMouseJoint.destroy( ) end
function MOAIBox2DMouseJoint.getAnchorA( ) end
function MOAIBox2DMouseJoint.getAnchorB( ) end
function MOAIBox2DMouseJoint.getBodyA( ) end
function MOAIBox2DMouseJoint.getBodyB( ) end
function MOAIBox2DMouseJoint.getDampingRatio( ) end
function MOAIBox2DMouseJoint.getFrequency( ) end
function MOAIBox2DMouseJoint.getMaxForce( ) end
function MOAIBox2DMouseJoint.getReactionForce( ) end
function MOAIBox2DMouseJoint.getReactionTorque( ) end
function MOAIBox2DMouseJoint.getTarget( ) end
function MOAIBox2DMouseJoint.setDampingRatio( ) end
function MOAIBox2DMouseJoint.setFrequency( ) end
function MOAIBox2DMouseJoint.setMaxForce( ) end
function MOAIBox2DMouseJoint.setTarget( ) end

-- MOAIBox2DPrismaticJoint
MOAIBox2DPrismaticJoint = { }

function MOAIBox2DPrismaticJoint.destroy( ) end
function MOAIBox2DPrismaticJoint.getAnchorA( ) end
function MOAIBox2DPrismaticJoint.getAnchorB( ) end
function MOAIBox2DPrismaticJoint.getBodyA( ) end
function MOAIBox2DPrismaticJoint.getBodyB( ) end
function MOAIBox2DPrismaticJoint.getJointSpeed( ) end
function MOAIBox2DPrismaticJoint.getJointTranslation( ) end
function MOAIBox2DPrismaticJoint.getLowerLimit( ) end
function MOAIBox2DPrismaticJoint.getMotorForce( ) end
function MOAIBox2DPrismaticJoint.getMotorSpeed( ) end
function MOAIBox2DPrismaticJoint.getReactionForce( ) end
function MOAIBox2DPrismaticJoint.getReactionTorque( ) end
function MOAIBox2DPrismaticJoint.getUpperLimit( ) end
function MOAIBox2DPrismaticJoint.isLimitEnabled( ) end
function MOAIBox2DPrismaticJoint.isMotorEnabled( ) end
function MOAIBox2DPrismaticJoint.setLimit( ) end
function MOAIBox2DPrismaticJoint.setLimitEnabled( ) end
function MOAIBox2DPrismaticJoint.setMaxMotorForce( ) end
function MOAIBox2DPrismaticJoint.setMotor( ) end
function MOAIBox2DPrismaticJoint.setMotorEnabled( ) end
function MOAIBox2DPrismaticJoint.setMotorSpeed( ) end

-- MOAIBox2DPulleyJoint
MOAIBox2DPulleyJoint = { }

function MOAIBox2DPulleyJoint.destroy( ) end
function MOAIBox2DPulleyJoint.getAnchorA( ) end
function MOAIBox2DPulleyJoint.getAnchorB( ) end
function MOAIBox2DPulleyJoint.getBodyA( ) end
function MOAIBox2DPulleyJoint.getBodyB( ) end
function MOAIBox2DPulleyJoint.getGroundAnchorA( ) end
function MOAIBox2DPulleyJoint.getGroundAnchorB( ) end
function MOAIBox2DPulleyJoint.getLength1( ) end
function MOAIBox2DPulleyJoint.getLength2( ) end
function MOAIBox2DPulleyJoint.getRatio( ) end
function MOAIBox2DPulleyJoint.getReactionForce( ) end
function MOAIBox2DPulleyJoint.getReactionTorque( ) end

-- MOAIBox2DRevoluteJoint
MOAIBox2DRevoluteJoint = { }

function MOAIBox2DRevoluteJoint.destroy( ) end
function MOAIBox2DRevoluteJoint.getAnchorA( ) end
function MOAIBox2DRevoluteJoint.getAnchorB( ) end
function MOAIBox2DRevoluteJoint.getBodyA( ) end
function MOAIBox2DRevoluteJoint.getBodyB( ) end
function MOAIBox2DRevoluteJoint.getJointAngle( ) end
function MOAIBox2DRevoluteJoint.getJointSpeed( ) end
function MOAIBox2DRevoluteJoint.getLowerLimit( ) end
function MOAIBox2DRevoluteJoint.getMotorSpeed( ) end
function MOAIBox2DRevoluteJoint.getMotorTorque( ) end
function MOAIBox2DRevoluteJoint.getReactionForce( ) end
function MOAIBox2DRevoluteJoint.getReactionTorque( ) end
function MOAIBox2DRevoluteJoint.getUpperLimit( ) end
function MOAIBox2DRevoluteJoint.isLimitEnabled( ) end
function MOAIBox2DRevoluteJoint.isMotorEnabled( ) end
function MOAIBox2DRevoluteJoint.setLimit( ) end
function MOAIBox2DRevoluteJoint.setLimitEnabled( ) end
function MOAIBox2DRevoluteJoint.setMaxMotorTorque( ) end
function MOAIBox2DRevoluteJoint.setMotor( ) end
function MOAIBox2DRevoluteJoint.setMotorEnabled( ) end
function MOAIBox2DRevoluteJoint.setMotorSpeed( ) end

-- MOAIBox2DRopeJoint
MOAIBox2DRopeJoint = { }

function MOAIBox2DRopeJoint.destroy( ) end
function MOAIBox2DRopeJoint.getAnchorA( ) end
function MOAIBox2DRopeJoint.getAnchorB( ) end
function MOAIBox2DRopeJoint.getBodyA( ) end
function MOAIBox2DRopeJoint.getBodyB( ) end
function MOAIBox2DRopeJoint.getLimitState( ) end
function MOAIBox2DRopeJoint.getMaxLength( ) end
function MOAIBox2DRopeJoint.getReactionForce( ) end
function MOAIBox2DRopeJoint.getReactionTorque( ) end
function MOAIBox2DRopeJoint.setMaxLength( ) end

-- MOAIBox2DWeldJoint
MOAIBox2DWeldJoint = { }

function MOAIBox2DWeldJoint.destroy( ) end
function MOAIBox2DWeldJoint.getAnchorA( ) end
function MOAIBox2DWeldJoint.getAnchorB( ) end
function MOAIBox2DWeldJoint.getBodyA( ) end
function MOAIBox2DWeldJoint.getBodyB( ) end
function MOAIBox2DWeldJoint.getReactionForce( ) end
function MOAIBox2DWeldJoint.getReactionTorque( ) end

-- MOAIBox2DWheelJoint
MOAIBox2DWheelJoint = { }

function MOAIBox2DWheelJoint.destroy( ) end
function MOAIBox2DWheelJoint.getAnchorA( ) end
function MOAIBox2DWheelJoint.getAnchorB( ) end
function MOAIBox2DWheelJoint.getBodyA( ) end
function MOAIBox2DWheelJoint.getBodyB( ) end
function MOAIBox2DWheelJoint.getJointSpeed( ) end
function MOAIBox2DWheelJoint.getJointTranslation( ) end
function MOAIBox2DWheelJoint.getMaxMotorTorque( ) end
function MOAIBox2DWheelJoint.getMotorSpeed( ) end
function MOAIBox2DWheelJoint.getMotorTorque( ) end
function MOAIBox2DWheelJoint.getReactionForce( ) end
function MOAIBox2DWheelJoint.getReactionTorque( ) end
function MOAIBox2DWheelJoint.getSpringDampingRatio( ) end
function MOAIBox2DWheelJoint.getSpringFrequencyHz( ) end
function MOAIBox2DWheelJoint.isMotorEnabled( ) end
function MOAIBox2DWheelJoint.setMaxMotorTorque( ) end
function MOAIBox2DWheelJoint.setMotor( ) end
function MOAIBox2DWheelJoint.setMotorEnabled( ) end
function MOAIBox2DWheelJoint.setMotorSpeed( ) end
function MOAIBox2DWheelJoint.setSpringDampingRatio( ) end
function MOAIBox2DWheelJoint.setSpringFrequencyHz( ) end

-- MOAIBox2DWorld
MOAIBox2DWorld = { }

function MOAIBox2DWorld.addBody( ) end
function MOAIBox2DWorld.addDistanceJoint( ) end
function MOAIBox2DWorld.addFrictionJoint( ) end
function MOAIBox2DWorld.addGearJoint( ) end
function MOAIBox2DWorld.addMouseJoint( ) end
function MOAIBox2DWorld.addPrismaticJoint( ) end
function MOAIBox2DWorld.addPulleyJoint( ) end
function MOAIBox2DWorld.addRevoluteJoint( ) end
function MOAIBox2DWorld.addRopeJoint( ) end
function MOAIBox2DWorld.addWeldJoint( ) end
function MOAIBox2DWorld.addWheelJoint( ) end
function MOAIBox2DWorld.getAngularSleepTolerance( ) end
function MOAIBox2DWorld.getAutoClearForces( ) end
function MOAIBox2DWorld.getGravity( ) end
function MOAIBox2DWorld.getLinearSleepTolerance( ) end
function MOAIBox2DWorld.getTimeToSleep( ) end
function MOAIBox2DWorld.setAngularSleepTolerance( ) end
function MOAIBox2DWorld.setAutoClearForces( ) end
function MOAIBox2DWorld.setGravity( ) end
function MOAIBox2DWorld.setIterations( ) end
function MOAIBox2DWorld.setLinearSleepTolerance( ) end
function MOAIBox2DWorld.setTimeToSleep( ) end
function MOAIBox2DWorld.setUnitsToMeters( ) end

-- MOAIBreakpoint
MOAIBreakpoint = { }

-- MOAIButtonSensor
MOAIButtonSensor = { }

function MOAIButtonSensor.down( ) end
function MOAIButtonSensor.isDown( ) end
function MOAIButtonSensor.isUp( ) end
function MOAIButtonSensor.setCallback( ) end
function MOAIButtonSensor.up( ) end

-- MOAICameraAnchor2D
MOAICameraAnchor2D = { }

function MOAICameraAnchor2D.setParent( ) end
function MOAICameraAnchor2D.setRect( ) end

-- MOAICameraFitter2D
MOAICameraFitter2D = { }
MOAICameraFitter2D.FITTING_MODE_SEEK_LOC = true
MOAICameraFitter2D.FITTING_MODE_SEEK_SCALE = true
MOAICameraFitter2D.FITTING_MODE_APPLY_ANCHORS = true
MOAICameraFitter2D.FITTING_MODE_APPLY_BOUNDS = true
MOAICameraFitter2D.FITTING_MODE_DEFAULT = true
MOAICameraFitter2D.FITTING_MODE_MASK = true

function MOAICameraFitter2D.clearAnchors( ) end
function MOAICameraFitter2D.clearFitMode( ) end
function MOAICameraFitter2D.getFitDistance( ) end
function MOAICameraFitter2D.getFitLoc( ) end
function MOAICameraFitter2D.getFitMode( ) end
function MOAICameraFitter2D.getFitScale( ) end
function MOAICameraFitter2D.getTargetLoc( ) end
function MOAICameraFitter2D.getTargetScale( ) end
function MOAICameraFitter2D.insertAnchor( ) end
function MOAICameraFitter2D.removeAnchor( ) end
function MOAICameraFitter2D.setBounds( ) end
function MOAICameraFitter2D.setCamera( ) end
function MOAICameraFitter2D.setDamper( ) end
function MOAICameraFitter2D.setFitLoc( ) end
function MOAICameraFitter2D.setFitMode( ) end
function MOAICameraFitter2D.setFitScale( ) end
function MOAICameraFitter2D.setMin( ) end
function MOAICameraFitter2D.setViewport( ) end
function MOAICameraFitter2D.snapToTarget( ) end

-- MOAIColor
MOAIColor = { }
MOAIColor.ATTR_R_COL = true
MOAIColor.ATTR_G_COL = true
MOAIColor.ATTR_B_COL = true
MOAIColor.ATTR_A_COL = true
MOAIColor.INHERIT_COLOR = true
MOAIColor.COLOR_TRAIT = true

function MOAIColor.moveColor( ) end
function MOAIColor.seekColor( ) end
function MOAIColor.setColor( ) end
function MOAIColor.setParent( ) end

-- MOAICompassSensor
MOAICompassSensor = { }

function MOAICompassSensor.getHeading( ) end
function MOAICompassSensor.setCallback( ) end

-- MOAICoroutine
MOAICoroutine = { }

function MOAICoroutine.blockOnAction( ) end
function MOAICoroutine.currentThread( ) end
function MOAICoroutine.run( ) end

-- MOAICp
MOAICp = { }

function MOAICp.getBiasCoefficient( ) end
function MOAICp.getCollisionSlop( ) end
function MOAICp.getContactPersistence( ) end
function MOAICp.setBiasCoefficient( ) end
function MOAICp.setCollisionSlop( ) end
function MOAICp.setContactPersistence( ) end

-- MOAICpArbiter
MOAICpArbiter = { }

function MOAICpArbiter.countContacts( ) end
function MOAICpArbiter.getContactDepth( ) end
function MOAICpArbiter.getContactNormal( ) end
function MOAICpArbiter.getContactPoint( ) end
function MOAICpArbiter.getTotalImpulse( ) end
function MOAICpArbiter.getTotalImpulseWithFriction( ) end
function MOAICpArbiter.isFirstContact( ) end

-- MOAICpBody
MOAICpBody = { }
MOAICpBody.NONE = true
MOAICpBody.REMOVE_BODY = true
MOAICpBody.REMOVE_BODY_AND_SHAPES = true

function MOAICpBody.activate( ) end
function MOAICpBody.addCircle( ) end
function MOAICpBody.addPolygon( ) end
function MOAICpBody.addRect( ) end
function MOAICpBody.addSegment( ) end
function MOAICpBody.applyForce( ) end
function MOAICpBody.applyImpulse( ) end
function MOAICpBody.getAngle( ) end
function MOAICpBody.getAngVel( ) end
function MOAICpBody.getForce( ) end
function MOAICpBody.getMass( ) end
function MOAICpBody.getMoment( ) end
function MOAICpBody.getPos( ) end
function MOAICpBody.getRot( ) end
function MOAICpBody.getTorque( ) end
function MOAICpBody.getVel( ) end
function MOAICpBody.getWorldDir( ) end
function MOAICpBody.getWorldLoc( ) end
function MOAICpBody.getWorldRot( ) end
function MOAICpBody.getWorldScl( ) end
function MOAICpBody.isRogue( ) end
function MOAICpBody.isSleeping( ) end
function MOAICpBody.isStatic( ) end
function MOAICpBody.localToWorld( ) end
function MOAICpBody.new( ) end
function MOAICpBody.newStatic( ) end
function MOAICpBody.resetForces( ) end
function MOAICpBody.setAngle( ) end
function MOAICpBody.setAngVel( ) end
function MOAICpBody.setForce( ) end
function MOAICpBody.setMass( ) end
function MOAICpBody.setMoment( ) end
function MOAICpBody.setPos( ) end
function MOAICpBody.setRemoveFlag( ) end
function MOAICpBody.setTorque( ) end
function MOAICpBody.setVel( ) end
function MOAICpBody.sleep( ) end
function MOAICpBody.sleepWithGroup( ) end
function MOAICpBody.worldToLocal( ) end

-- MOAICpConstraint
MOAICpConstraint = { }

function MOAICpConstraint.getBiasCoef( ) end
function MOAICpConstraint.getMaxBias( ) end
function MOAICpConstraint.getMaxForce( ) end
function MOAICpConstraint.newDampedRotarySpring( ) end
function MOAICpConstraint.newDampedSpring( ) end
function MOAICpConstraint.newGearJoint( ) end
function MOAICpConstraint.newGrooveJoint( ) end
function MOAICpConstraint.newPinJoint( ) end
function MOAICpConstraint.newPivotJoint( ) end
function MOAICpConstraint.newRatchetJoint( ) end
function MOAICpConstraint.newRotaryLimitJoint( ) end
function MOAICpConstraint.newSimpleMotor( ) end
function MOAICpConstraint.newSlideJoint( ) end
function MOAICpConstraint.setBiasCoef( ) end
function MOAICpConstraint.setMaxBias( ) end
function MOAICpConstraint.setMaxForce( ) end

-- MOAICpShape
MOAICpShape = { }

function MOAICpShape.areaForCircle( ) end
function MOAICpShape.areaForPolygon( ) end
function MOAICpShape.areaForRect( ) end
function MOAICpShape.areaForSegment( ) end
function MOAICpShape.getBody( ) end
function MOAICpShape.getElasticity( ) end
function MOAICpShape.getFriction( ) end
function MOAICpShape.getGroup( ) end
function MOAICpShape.getLayers( ) end
function MOAICpShape.getSurfaceVel( ) end
function MOAICpShape.getType( ) end
function MOAICpShape.inside( ) end
function MOAICpShape.isSensor( ) end
function MOAICpShape.momentForCircle( ) end
function MOAICpShape.momentForPolygon( ) end
function MOAICpShape.momentForRect( ) end
function MOAICpShape.momentForSegment( ) end
function MOAICpShape.setElasticity( ) end
function MOAICpShape.setFriction( ) end
function MOAICpShape.setGroup( ) end
function MOAICpShape.setIsSensor( ) end
function MOAICpShape.setLayers( ) end
function MOAICpShape.setSurfaceVel( ) end
function MOAICpShape.setType( ) end

-- MOAICpSpace
MOAICpSpace = { }
MOAICpSpace.BEGIN = true
MOAICpSpace.PRE_SOLVE = true
MOAICpSpace.POST_SOLVE = true
MOAICpSpace.SEPARATE = true
MOAICpSpace.ALL = true

function MOAICpSpace.activateShapesTouchingShape( ) end
function MOAICpSpace.getDamping( ) end
function MOAICpSpace.getGravity( ) end
function MOAICpSpace.getIdleSpeedThreshold( ) end
function MOAICpSpace.getIterations( ) end
function MOAICpSpace.getSleepTimeThreshold( ) end
function MOAICpSpace.getStaticBody( ) end
function MOAICpSpace.insertProp( ) end
function MOAICpSpace.rehashShape( ) end
function MOAICpSpace.rehashStatic( ) end
function MOAICpSpace.removeProp( ) end
function MOAICpSpace.resizeActiveHash( ) end
function MOAICpSpace.resizeStaticHash( ) end
function MOAICpSpace.setCollisionHandler( ) end
function MOAICpSpace.setDamping( ) end
function MOAICpSpace.setGravity( ) end
function MOAICpSpace.setIdleSpeedThreshold( ) end
function MOAICpSpace.setIterations( ) end
function MOAICpSpace.setSleepTimeThreshold( ) end
function MOAICpSpace.shapeForPoint( ) end
function MOAICpSpace.shapeForSegment( ) end
function MOAICpSpace.shapeListForPoint( ) end
function MOAICpSpace.shapeListForRect( ) end
function MOAICpSpace.shapeListForSegment( ) end

-- MOAIDataBuffer
MOAIDataBuffer = { }

function MOAIDataBuffer.base64Decode( ) end
function MOAIDataBuffer.base64Encode( ) end
function MOAIDataBuffer.deflate( ) end
function MOAIDataBuffer.getSize( ) end
function MOAIDataBuffer.getString( ) end
function MOAIDataBuffer.inflate( ) end
function MOAIDataBuffer.load( ) end
function MOAIDataBuffer.loadAsync( ) end
function MOAIDataBuffer.save( ) end
function MOAIDataBuffer.saveAsync( ) end
function MOAIDataBuffer.setString( ) end
function MOAIDataBuffer.toCppHeader( ) end

-- MOAIDataIOAction
MOAIDataIOAction = { }

function MOAIDataIOAction.setCallback( ) end

-- MOAIDebugLines
MOAIDebugLines = { }
MOAIDebugLines.PARTITION_CELLS = true
MOAIDebugLines.PARTITION_PADDED_CELLS = true
MOAIDebugLines.PROP_MODEL_BOUNDS = true
MOAIDebugLines.PROP_WORLD_BOUNDS = true
MOAIDebugLines.TEXT_BOX = true

function MOAIDebugLines.setStyle( ) end
function MOAIDebugLines.showStyle( ) end

-- MOAIDeck
MOAIDeck = { }

function MOAIDeck.setShader( ) end

-- MOAIDeck2D
MOAIDeck2D = { }

function MOAIDeck2D.setShader( ) end

-- MOAIDeckRemapper
MOAIDeckRemapper = { }

function MOAIDeckRemapper.reserve( ) end
function MOAIDeckRemapper.setBase( ) end
function MOAIDeckRemapper.setRemap( ) end

-- MOAIDraw
MOAIDraw = { }

function MOAIDraw.drawCircle( ) end
function MOAIDraw.drawEllipse( ) end
function MOAIDraw.drawLine( ) end
function MOAIDraw.drawPoints( ) end
function MOAIDraw.drawRay( ) end
function MOAIDraw.drawRect( ) end
function MOAIDraw.fillCircle( ) end
function MOAIDraw.fillEllipse( ) end
function MOAIDraw.fillFan( ) end
function MOAIDraw.fillRect( ) end

-- MOAIEaseDriver
MOAIEaseDriver = { }

function MOAIEaseDriver.reserveLinks( ) end
function MOAIEaseDriver.setLength( ) end
function MOAIEaseDriver.setLink( ) end

-- MOAIEaseType
MOAIEaseType = { }
MOAIEaseType.EASE_IN = true
MOAIEaseType.EASE_OUT = true
MOAIEaseType.FLAT = true
MOAIEaseType.LINEAR = true
MOAIEaseType.SHARP_EASE_IN = true
MOAIEaseType.SHARP_EASE_OUT = true
MOAIEaseType.SHARP_SMOOTH = true
MOAIEaseType.SMOOTH = true
MOAIEaseType.SOFT_EASE_IN = true
MOAIEaseType.SOFT_EASE_OUT = true
MOAIEaseType.SOFT_SMOOTH = true

-- MOAIEnvironment
MOAIEnvironment = { }
MOAIEnvironment.CONNECTION_TYPE_NONE = true
MOAIEnvironment.CONNECTION_TYPE_WIFI = true
MOAIEnvironment.CONNECTION_TYPE_WWAN = true
MOAIEnvironment.OS_BRAND_ANDROID = true
MOAIEnvironment.OS_BRAND_IOS = true
MOAIEnvironment.OS_BRAND_UNAVAILABLE = true

function MOAIEnvironment.generateGUID( ) end
function MOAIEnvironment.getAppDisplayName( ) end
function MOAIEnvironment.getAppID( ) end
function MOAIEnvironment.getAppVersion( ) end
function MOAIEnvironment.getCacheDirectory( ) end
function MOAIEnvironment.getCarrierISOCountryCode( ) end
function MOAIEnvironment.getCarrierMobileCountryCode( ) end
function MOAIEnvironment.getCarrierMobileNetworkCode( ) end
function MOAIEnvironment.getCarrierName( ) end
function MOAIEnvironment.getConnectionType( ) end
function MOAIEnvironment.getCountryCode( ) end
function MOAIEnvironment.getCPUABI( ) end
function MOAIEnvironment.getDevBrand( ) end
function MOAIEnvironment.getDevManufacturer( ) end
function MOAIEnvironment.getDevModel( ) end
function MOAIEnvironment.getDevName( ) end
function MOAIEnvironment.getDevProduct( ) end
function MOAIEnvironment.getDocumentDirectory( ) end
function MOAIEnvironment.getLanguageCode( ) end
function MOAIEnvironment.getOSBrand( ) end
function MOAIEnvironment.getOSVersion( ) end
function MOAIEnvironment.getResourceDirectory( ) end
function MOAIEnvironment.getScreenSize( ) end
function MOAIEnvironment.getUDID( ) end
function MOAIEnvironment.getViewSize( ) end
function MOAIEnvironment.isRetinaDisplay( ) end

-- MOAIEventSource
MOAIEventSource = { }

-- MOAIFileSystem
MOAIFileSystem = { }

function MOAIFileSystem.affirmPath( ) end
function MOAIFileSystem.checkFileExists( ) end
function MOAIFileSystem.checkPathExists( ) end
function MOAIFileSystem.deleteDirectory( ) end
function MOAIFileSystem.deleteFile( ) end
function MOAIFileSystem.getAbsoluteDirectoryPath( ) end
function MOAIFileSystem.getAbsoluteFilePath( ) end
function MOAIFileSystem.getWorkingDirectory( ) end
function MOAIFileSystem.listDirectories( ) end
function MOAIFileSystem.listFiles( ) end
function MOAIFileSystem.mountVirtualDirectory( ) end
function MOAIFileSystem.rename( ) end
function MOAIFileSystem.setWorkingDirectory( ) end

-- MOAIFmod
MOAIFmod = { }

function MOAIFmod.getMemoryStats( ) end
function MOAIFmod.init( ) end

-- MOAIFmodChannel
MOAIFmodChannel = { }

function MOAIFmodChannel.getVolume( ) end
function MOAIFmodChannel.isPlaying( ) end
function MOAIFmodChannel.moveVolume( ) end
function MOAIFmodChannel.play( ) end
function MOAIFmodChannel.seekVolume( ) end
function MOAIFmodChannel.setLooping( ) end
function MOAIFmodChannel.setPaused( ) end
function MOAIFmodChannel.setVolume( ) end
function MOAIFmodChannel.stop( ) end

-- MOAIFmodSound
MOAIFmodSound = { }

function MOAIFmodSound.load( ) end
function MOAIFmodSound.loadBGM( ) end
function MOAIFmodSound.loadSFX( ) end
function MOAIFmodSound.release( ) end

-- MOAIFont
MOAIFont = { }

function MOAIFont.getImage( ) end
function MOAIFont.getLineScale( ) end
function MOAIFont.getScale( ) end
function MOAIFont.getTexture( ) end
function MOAIFont.load( ) end
function MOAIFont.loadFromTTF( ) end
function MOAIFont.setImage( ) end
function MOAIFont.setTexture( ) end

-- MOAIGameCenter
MOAIGameCenter = { }
MOAIGameCenter.TIMESCOPE_TODAY = true
MOAIGameCenter.TIMESCOPE_WEEK = true
MOAIGameCenter.TIMESCOPE_ALLTIME = true
MOAIGameCenter.PLAYERSCOPE_GLOBAL = true
MOAIGameCenter.PLAYERSCOPE_FRIENDS = true

-- MOAIGfxDevice
MOAIGfxDevice = { }

function MOAIGfxDevice.isProgrammable( ) end
function MOAIGfxDevice.setClearColor( ) end
function MOAIGfxDevice.setClearDepth( ) end
function MOAIGfxDevice.setPenColor( ) end
function MOAIGfxDevice.setPenWidth( ) end
function MOAIGfxDevice.setPointSize( ) end

-- MOAIGfxQuad2D
MOAIGfxQuad2D = { }

function MOAIGfxQuad2D.setRect( ) end
function MOAIGfxQuad2D.setShader( ) end
function MOAIGfxQuad2D.setTexture( ) end
function MOAIGfxQuad2D.setUVRect( ) end

-- MOAIGfxQuadDeck2D
MOAIGfxQuadDeck2D = { }

function MOAIGfxQuadDeck2D.reserve( ) end
function MOAIGfxQuadDeck2D.setQuad( ) end
function MOAIGfxQuadDeck2D.setRect( ) end
function MOAIGfxQuadDeck2D.setShader( ) end
function MOAIGfxQuadDeck2D.setTexture( ) end
function MOAIGfxQuadDeck2D.setUVQuad( ) end
function MOAIGfxQuadDeck2D.setUVRect( ) end

-- MOAIGfxQuadListDeck2D
MOAIGfxQuadListDeck2D = { }

function MOAIGfxQuadListDeck2D.reserveLists( ) end
function MOAIGfxQuadListDeck2D.reservePairs( ) end
function MOAIGfxQuadListDeck2D.reserveQuads( ) end
function MOAIGfxQuadListDeck2D.reserveUVQuads( ) end
function MOAIGfxQuadListDeck2D.setList( ) end
function MOAIGfxQuadListDeck2D.setPair( ) end
function MOAIGfxQuadListDeck2D.setQuad( ) end
function MOAIGfxQuadListDeck2D.setRect( ) end
function MOAIGfxQuadListDeck2D.setShader( ) end
function MOAIGfxQuadListDeck2D.setTexture( ) end
function MOAIGfxQuadListDeck2D.setUVQuad( ) end
function MOAIGfxQuadListDeck2D.setUVRect( ) end

-- MOAIGlobalEventSource
MOAIGlobalEventSource = { }

-- MOAIGrid
MOAIGrid = { }

function MOAIGrid.cellAddrToCoord( ) end
function MOAIGrid.clearTileFlags( ) end
function MOAIGrid.getCellAddr( ) end
function MOAIGrid.getCellSize( ) end
function MOAIGrid.getOffset( ) end
function MOAIGrid.getSize( ) end
function MOAIGrid.getTile( ) end
function MOAIGrid.getTileFlags( ) end
function MOAIGrid.getTileLoc( ) end
function MOAIGrid.getTileSize( ) end
function MOAIGrid.initDiamondGrid( ) end
function MOAIGrid.initHexGrid( ) end
function MOAIGrid.initObliqueGrid( ) end
function MOAIGrid.initRectGrid( ) end
function MOAIGrid.locToCellAddr( ) end
function MOAIGrid.locToCoord( ) end
function MOAIGrid.setRepeat( ) end
function MOAIGrid.setRow( ) end
function MOAIGrid.setShape( ) end
function MOAIGrid.setSize( ) end
function MOAIGrid.setTile( ) end
function MOAIGrid.setTileFlags( ) end
function MOAIGrid.toggleTileFlags( ) end
function MOAIGrid.wrapCoord( ) end

-- MOAIGridPathGraph
MOAIGridPathGraph = { }

function MOAIGridPathGraph.setGrid( ) end

-- MOAIGridSpace
MOAIGridSpace = { }
MOAIGridSpace.TILE_BOTTOM_CENTER = true
MOAIGridSpace.TILE_CENTER = true
MOAIGridSpace.TILE_LEFT_BOTTOM = true
MOAIGridSpace.TILE_LEFT_CENTER = true
MOAIGridSpace.TILE_LEFT_TOP = true
MOAIGridSpace.TILE_RIGHT_BOTTOM = true
MOAIGridSpace.TILE_RIGHT_CENTER = true
MOAIGridSpace.TILE_RIGHT_TOP = true
MOAIGridSpace.TILE_TOP_CENTER = true
MOAIGridSpace.SQUARE_SHAPE = true
MOAIGridSpace.DIAMOND_SHAPE = true
MOAIGridSpace.OBLIQUE_SHAPE = true
MOAIGridSpace.HEX_SHAPE = true
MOAIGridSpace.TILE_X_FLIP = true
MOAIGridSpace.TILE_Y_FLIP = true
MOAIGridSpace.TILE_XY_FLIP = true
MOAIGridSpace.TILE_HIDE = true

function MOAIGridSpace.cellAddrToCoord( ) end
function MOAIGridSpace.getCellAddr( ) end
function MOAIGridSpace.getCellSize( ) end
function MOAIGridSpace.getOffset( ) end
function MOAIGridSpace.getSize( ) end
function MOAIGridSpace.getTileLoc( ) end
function MOAIGridSpace.getTileSize( ) end
function MOAIGridSpace.initDiamondGrid( ) end
function MOAIGridSpace.initHexGrid( ) end
function MOAIGridSpace.initObliqueGrid( ) end
function MOAIGridSpace.initRectGrid( ) end
function MOAIGridSpace.locToCellAddr( ) end
function MOAIGridSpace.locToCoord( ) end
function MOAIGridSpace.setRepeat( ) end
function MOAIGridSpace.setShape( ) end
function MOAIGridSpace.setSize( ) end
function MOAIGridSpace.wrapCoord( ) end

-- MOAIHarness
MOAIHarness = { }

-- MOAIHttpTask
MOAIHttpTask = { }

function MOAIHttpTask.getSize( ) end
function MOAIHttpTask.getString( ) end
function MOAIHttpTask.httpGet( ) end
function MOAIHttpTask.httpPost( ) end
function MOAIHttpTask.parseXml( ) end
function MOAIHttpTask.setCallback( ) end

-- MOAIImage
MOAIImage = { }
MOAIImage.FILTER_LINEAR = true
MOAIImage.FILTER_NEAREST = true
MOAIImage.POW_TWO = true
MOAIImage.QUANTIZE = true
MOAIImage.TRUECOLOR = true
MOAIImage.PREMULTIPLY_ALPHA = true
MOAIImage.PIXEL_FMT_TRUECOLOR = true
MOAIImage.PIXEL_FMT_INDEX_4 = true
MOAIImage.PIXEL_FMT_INDEX_8 = true
MOAIImage.COLOR_FMT_A_8 = true
MOAIImage.COLOR_FMT_RGB_888 = true
MOAIImage.COLOR_FMT_RGB_565 = true
MOAIImage.COLOR_FMT_RGBA_5551 = true
MOAIImage.COLOR_FMT_RGBA_4444 = true
MOAIImage.COLOR_FMT_RGBA_8888 = true

function MOAIImage.bleedRect( ) end
function MOAIImage.convertColors( ) end
function MOAIImage.copy( ) end
function MOAIImage.copyBits( ) end
function MOAIImage.copyRect( ) end
function MOAIImage.getColor32( ) end
function MOAIImage.getFormat( ) end
function MOAIImage.getRGBA( ) end
function MOAIImage.getSize( ) end
function MOAIImage.init( ) end
function MOAIImage.load( ) end
function MOAIImage.padToPow2( ) end
function MOAIImage.resize( ) end
function MOAIImage.resizeCanvas( ) end
function MOAIImage.setColor32( ) end
function MOAIImage.setRGBA( ) end
function MOAIImage.writePNG( ) end

-- MOAIIndexBuffer
MOAIIndexBuffer = { }

function MOAIIndexBuffer.release( ) end
function MOAIIndexBuffer.reserve( ) end
function MOAIIndexBuffer.setIndex( ) end

-- MOAIInputDevice
MOAIInputDevice = { }

-- MOAIInputMgr
MOAIInputMgr = { }

-- MOAIInstanceEventSource
MOAIInstanceEventSource = { }

function MOAIInstanceEventSource.setListener( ) end

-- MOAIJoystickSensor
MOAIJoystickSensor = { }

function MOAIJoystickSensor.getVector( ) end
function MOAIJoystickSensor.setCallback( ) end

-- MOAIJsonParser
MOAIJsonParser = { }

function MOAIJsonParser.decode( ) end
function MOAIJsonParser.encode( ) end

-- MOAIKeyboardSensor
MOAIKeyboardSensor = { }

function MOAIKeyboardSensor.keyDown( ) end
function MOAIKeyboardSensor.keyIsDown( ) end
function MOAIKeyboardSensor.keyIsUp( ) end
function MOAIKeyboardSensor.keyUp( ) end
function MOAIKeyboardSensor.setCallback( ) end

-- MOAILayer2D
MOAILayer2D = { }
MOAILayer2D.SORT_NONE = true
MOAILayer2D.SORT_PRIORITY_ASCENDING = true
MOAILayer2D.SORT_PRIORITY_DESCENDING = true
MOAILayer2D.SORT_X_ASCENDING = true
MOAILayer2D.SORT_X_DESCENDING = true
MOAILayer2D.SORT_Y_ASCENDING = true
MOAILayer2D.SORT_Y_DESCENDING = true
MOAILayer2D.SORT_VECTOR_ASCENDING = true
MOAILayer2D.SORT_VECTOR_DESCENDING = true

function MOAILayer2D.addLoc( ) end
function MOAILayer2D.addPiv( ) end
function MOAILayer2D.addRot( ) end
function MOAILayer2D.addScl( ) end
function MOAILayer2D.clear( ) end
function MOAILayer2D.getFitting( ) end
function MOAILayer2D.getGrid( ) end
function MOAILayer2D.getIndex( ) end
function MOAILayer2D.getLoc( ) end
function MOAILayer2D.getPartition( ) end
function MOAILayer2D.getPiv( ) end
function MOAILayer2D.getRect( ) end
function MOAILayer2D.getRot( ) end
function MOAILayer2D.getScl( ) end
function MOAILayer2D.getSortMode( ) end
function MOAILayer2D.getWorldDir( ) end
function MOAILayer2D.getWorldLoc( ) end
function MOAILayer2D.getWorldRot( ) end
function MOAILayer2D.getWorldScl( ) end
function MOAILayer2D.insertProp( ) end
function MOAILayer2D.inside( ) end
function MOAILayer2D.modelToWorld( ) end
function MOAILayer2D.move( ) end
function MOAILayer2D.moveColor( ) end
function MOAILayer2D.moveLoc( ) end
function MOAILayer2D.movePiv( ) end
function MOAILayer2D.moveRot( ) end
function MOAILayer2D.moveScl( ) end
function MOAILayer2D.removeProp( ) end
function MOAILayer2D.seek( ) end
function MOAILayer2D.seekColor( ) end
function MOAILayer2D.seekLoc( ) end
function MOAILayer2D.seekPiv( ) end
function MOAILayer2D.seekRot( ) end
function MOAILayer2D.seekScl( ) end
function MOAILayer2D.setBlendMode( ) end
function MOAILayer2D.setBox2DWorld( ) end
function MOAILayer2D.setCamera( ) end
function MOAILayer2D.setColor( ) end
function MOAILayer2D.setCpSpace( ) end
function MOAILayer2D.setDeck( ) end
function MOAILayer2D.setExpandForSort( ) end
function MOAILayer2D.setFrame( ) end
function MOAILayer2D.setFrameBuffer( ) end
function MOAILayer2D.setGrid( ) end
function MOAILayer2D.setGridScale( ) end
function MOAILayer2D.setIndex( ) end
function MOAILayer2D.setLoc( ) end
function MOAILayer2D.setParallax( ) end
function MOAILayer2D.setParent( ) end
function MOAILayer2D.setPartition( ) end
function MOAILayer2D.setPiv( ) end
function MOAILayer2D.setRemapper( ) end
function MOAILayer2D.setRot( ) end
function MOAILayer2D.setScl( ) end
function MOAILayer2D.setShader( ) end
function MOAILayer2D.setSortMode( ) end
function MOAILayer2D.setSortScale( ) end
function MOAILayer2D.setUVTransform( ) end
function MOAILayer2D.setViewport( ) end
function MOAILayer2D.setVisible( ) end
function MOAILayer2D.showDebugLines( ) end
function MOAILayer2D.wndToWorld( ) end
function MOAILayer2D.worldToModel( ) end
function MOAILayer2D.worldToWnd( ) end

-- MOAILayerBridge2D
MOAILayerBridge2D = { }

function MOAILayerBridge2D.addLoc( ) end
function MOAILayerBridge2D.addPiv( ) end
function MOAILayerBridge2D.addRot( ) end
function MOAILayerBridge2D.addScl( ) end
function MOAILayerBridge2D.getLoc( ) end
function MOAILayerBridge2D.getPiv( ) end
function MOAILayerBridge2D.getRot( ) end
function MOAILayerBridge2D.getScl( ) end
function MOAILayerBridge2D.getWorldDir( ) end
function MOAILayerBridge2D.getWorldLoc( ) end
function MOAILayerBridge2D.getWorldRot( ) end
function MOAILayerBridge2D.getWorldScl( ) end
function MOAILayerBridge2D.init( ) end
function MOAILayerBridge2D.modelToWorld( ) end
function MOAILayerBridge2D.move( ) end
function MOAILayerBridge2D.moveLoc( ) end
function MOAILayerBridge2D.movePiv( ) end
function MOAILayerBridge2D.moveRot( ) end
function MOAILayerBridge2D.moveScl( ) end
function MOAILayerBridge2D.seek( ) end
function MOAILayerBridge2D.seekLoc( ) end
function MOAILayerBridge2D.seekPiv( ) end
function MOAILayerBridge2D.seekRot( ) end
function MOAILayerBridge2D.seekScl( ) end
function MOAILayerBridge2D.setLoc( ) end
function MOAILayerBridge2D.setParent( ) end
function MOAILayerBridge2D.setPiv( ) end
function MOAILayerBridge2D.setRot( ) end
function MOAILayerBridge2D.setScl( ) end
function MOAILayerBridge2D.worldToModel( ) end

-- MOAILocationSensor
MOAILocationSensor = { }

function MOAILocationSensor.getLocation( ) end
function MOAILocationSensor.setCallback( ) end

-- MOAILogMgr
MOAILogMgr = { }
MOAILogMgr.LOG_NONE = true
MOAILogMgr.LOG_ERROR = true
MOAILogMgr.LOG_WARNING = true
MOAILogMgr.LOG_STATUS = true

function MOAILogMgr.closeFile( ) end
function MOAILogMgr.isDebugBuild( ) end
function MOAILogMgr.log( ) end
function MOAILogMgr.openFile( ) end
function MOAILogMgr.registerLogMessage( ) end
function MOAILogMgr.setLogLevel( ) end

-- MOAIMesh
MOAIMesh = { }

function MOAIMesh.setShader( ) end
function MOAIMesh.setTexture( ) end
function MOAIMesh.setVertexBuffer( ) end

-- MOAIMotionSensor
MOAIMotionSensor = { }

function MOAIMotionSensor.getLevel( ) end
function MOAIMotionSensor.setCallback( ) end

-- MOAINode
MOAINode = { }

function MOAINode.clearAttrLink( ) end
function MOAINode.clearNodeLink( ) end
function MOAINode.forceUpdate( ) end
function MOAINode.getAttr( ) end
function MOAINode.getAttrLink( ) end
function MOAINode.moveAttr( ) end
function MOAINode.scheduleUpdate( ) end
function MOAINode.seekAttr( ) end
function MOAINode.setAttr( ) end
function MOAINode.setAttrLink( ) end
function MOAINode.setNodeLink( ) end

-- MOAIParser
MOAIParser = { }

function MOAIParser.loadFile( ) end
function MOAIParser.loadRules( ) end
function MOAIParser.loadString( ) end
function MOAIParser.setCallbacks( ) end
function MOAIParser.traverse( ) end

-- MOAIParticleDistanceEmitter
MOAIParticleDistanceEmitter = { }

function MOAIParticleDistanceEmitter.addLoc( ) end
function MOAIParticleDistanceEmitter.addPiv( ) end
function MOAIParticleDistanceEmitter.addRot( ) end
function MOAIParticleDistanceEmitter.addScl( ) end
function MOAIParticleDistanceEmitter.getLoc( ) end
function MOAIParticleDistanceEmitter.getPiv( ) end
function MOAIParticleDistanceEmitter.getRot( ) end
function MOAIParticleDistanceEmitter.getScl( ) end
function MOAIParticleDistanceEmitter.getWorldDir( ) end
function MOAIParticleDistanceEmitter.getWorldLoc( ) end
function MOAIParticleDistanceEmitter.getWorldRot( ) end
function MOAIParticleDistanceEmitter.getWorldScl( ) end
function MOAIParticleDistanceEmitter.modelToWorld( ) end
function MOAIParticleDistanceEmitter.move( ) end
function MOAIParticleDistanceEmitter.moveLoc( ) end
function MOAIParticleDistanceEmitter.movePiv( ) end
function MOAIParticleDistanceEmitter.moveRot( ) end
function MOAIParticleDistanceEmitter.moveScl( ) end
function MOAIParticleDistanceEmitter.reset( ) end
function MOAIParticleDistanceEmitter.seek( ) end
function MOAIParticleDistanceEmitter.seekLoc( ) end
function MOAIParticleDistanceEmitter.seekPiv( ) end
function MOAIParticleDistanceEmitter.seekRot( ) end
function MOAIParticleDistanceEmitter.seekScl( ) end
function MOAIParticleDistanceEmitter.setAngle( ) end
function MOAIParticleDistanceEmitter.setDistance( ) end
function MOAIParticleDistanceEmitter.setEmission( ) end
function MOAIParticleDistanceEmitter.setLoc( ) end
function MOAIParticleDistanceEmitter.setMagnitude( ) end
function MOAIParticleDistanceEmitter.setParent( ) end
function MOAIParticleDistanceEmitter.setPiv( ) end
function MOAIParticleDistanceEmitter.setRadius( ) end
function MOAIParticleDistanceEmitter.setRect( ) end
function MOAIParticleDistanceEmitter.setRot( ) end
function MOAIParticleDistanceEmitter.setScl( ) end
function MOAIParticleDistanceEmitter.setSystem( ) end
function MOAIParticleDistanceEmitter.surge( ) end
function MOAIParticleDistanceEmitter.worldToModel( ) end

-- MOAIParticleEmitter
MOAIParticleEmitter = { }

function MOAIParticleEmitter.addLoc( ) end
function MOAIParticleEmitter.addPiv( ) end
function MOAIParticleEmitter.addRot( ) end
function MOAIParticleEmitter.addScl( ) end
function MOAIParticleEmitter.getLoc( ) end
function MOAIParticleEmitter.getPiv( ) end
function MOAIParticleEmitter.getRot( ) end
function MOAIParticleEmitter.getScl( ) end
function MOAIParticleEmitter.getWorldDir( ) end
function MOAIParticleEmitter.getWorldLoc( ) end
function MOAIParticleEmitter.getWorldRot( ) end
function MOAIParticleEmitter.getWorldScl( ) end
function MOAIParticleEmitter.modelToWorld( ) end
function MOAIParticleEmitter.move( ) end
function MOAIParticleEmitter.moveLoc( ) end
function MOAIParticleEmitter.movePiv( ) end
function MOAIParticleEmitter.moveRot( ) end
function MOAIParticleEmitter.moveScl( ) end
function MOAIParticleEmitter.seek( ) end
function MOAIParticleEmitter.seekLoc( ) end
function MOAIParticleEmitter.seekPiv( ) end
function MOAIParticleEmitter.seekRot( ) end
function MOAIParticleEmitter.seekScl( ) end
function MOAIParticleEmitter.setAngle( ) end
function MOAIParticleEmitter.setEmission( ) end
function MOAIParticleEmitter.setLoc( ) end
function MOAIParticleEmitter.setMagnitude( ) end
function MOAIParticleEmitter.setParent( ) end
function MOAIParticleEmitter.setPiv( ) end
function MOAIParticleEmitter.setRadius( ) end
function MOAIParticleEmitter.setRect( ) end
function MOAIParticleEmitter.setRot( ) end
function MOAIParticleEmitter.setScl( ) end
function MOAIParticleEmitter.setSystem( ) end
function MOAIParticleEmitter.surge( ) end
function MOAIParticleEmitter.worldToModel( ) end

-- MOAIParticleForce
MOAIParticleForce = { }
MOAIParticleForce.FORCE = true
MOAIParticleForce.GRAVITY = true
MOAIParticleForce.OFFSET = true

function MOAIParticleForce.addLoc( ) end
function MOAIParticleForce.addPiv( ) end
function MOAIParticleForce.addRot( ) end
function MOAIParticleForce.addScl( ) end
function MOAIParticleForce.getLoc( ) end
function MOAIParticleForce.getPiv( ) end
function MOAIParticleForce.getRot( ) end
function MOAIParticleForce.getScl( ) end
function MOAIParticleForce.getWorldDir( ) end
function MOAIParticleForce.getWorldLoc( ) end
function MOAIParticleForce.getWorldRot( ) end
function MOAIParticleForce.getWorldScl( ) end
function MOAIParticleForce.initAttractor( ) end
function MOAIParticleForce.initBasin( ) end
function MOAIParticleForce.initLinear( ) end
function MOAIParticleForce.initRadial( ) end
function MOAIParticleForce.modelToWorld( ) end
function MOAIParticleForce.move( ) end
function MOAIParticleForce.moveLoc( ) end
function MOAIParticleForce.movePiv( ) end
function MOAIParticleForce.moveRot( ) end
function MOAIParticleForce.moveScl( ) end
function MOAIParticleForce.seek( ) end
function MOAIParticleForce.seekLoc( ) end
function MOAIParticleForce.seekPiv( ) end
function MOAIParticleForce.seekRot( ) end
function MOAIParticleForce.seekScl( ) end
function MOAIParticleForce.setLoc( ) end
function MOAIParticleForce.setParent( ) end
function MOAIParticleForce.setPiv( ) end
function MOAIParticleForce.setRot( ) end
function MOAIParticleForce.setScl( ) end
function MOAIParticleForce.setType( ) end
function MOAIParticleForce.worldToModel( ) end

-- MOAIParticlePlugin
MOAIParticlePlugin = { }

function MOAIParticlePlugin.getSize( ) end

-- MOAIParticleScript
MOAIParticleScript = { }
MOAIParticleScript.PARTICLE_X = true
MOAIParticleScript.PARTICLE_Y = true
MOAIParticleScript.PARTICLE_DX = true
MOAIParticleScript.PARTICLE_DY = true
MOAIParticleScript.SPRITE_X_LOC = true
MOAIParticleScript.SPRITE_Y_LOC = true
MOAIParticleScript.SPRITE_ROT = true
MOAIParticleScript.SPRITE_X_SCL = true
MOAIParticleScript.SPRITE_Y_SCL = true
MOAIParticleScript.SPRITE_RED = true
MOAIParticleScript.SPRITE_GREEN = true
MOAIParticleScript.SPRITE_BLUE = true
MOAIParticleScript.SPRITE_OPACITY = true
MOAIParticleScript.SPRITE_GLOW = true
MOAIParticleScript.SPRITE_IDX = true

function MOAIParticleScript.add( ) end
function MOAIParticleScript.atan2rot( ) end
function MOAIParticleScript.cycle( ) end
function MOAIParticleScript.div( ) end
function MOAIParticleScript.ease( ) end
function MOAIParticleScript.easeDelta( ) end
function MOAIParticleScript.mul( ) end
function MOAIParticleScript.packConst( ) end
function MOAIParticleScript.packReg( ) end
function MOAIParticleScript.rand( ) end
function MOAIParticleScript.randVec( ) end
function MOAIParticleScript.set( ) end
function MOAIParticleScript.sprite( ) end
function MOAIParticleScript.sub( ) end
function MOAIParticleScript.time( ) end
function MOAIParticleScript.vecAngle( ) end
function MOAIParticleScript.wrap( ) end

-- MOAIParticleState
MOAIParticleState = { }

function MOAIParticleState.clearForces( ) end
function MOAIParticleState.pushForce( ) end
function MOAIParticleState.setDamping( ) end
function MOAIParticleState.setInitScript( ) end
function MOAIParticleState.setMass( ) end
function MOAIParticleState.setNext( ) end
function MOAIParticleState.setPlugin( ) end
function MOAIParticleState.setRenderScript( ) end
function MOAIParticleState.setTerm( ) end

-- MOAIParticleSystem
MOAIParticleSystem = { }

function MOAIParticleSystem.addLoc( ) end
function MOAIParticleSystem.addPiv( ) end
function MOAIParticleSystem.addRot( ) end
function MOAIParticleSystem.addScl( ) end
function MOAIParticleSystem.capParticles( ) end
function MOAIParticleSystem.capSprites( ) end
function MOAIParticleSystem.clearSprites( ) end
function MOAIParticleSystem.getGrid( ) end
function MOAIParticleSystem.getIndex( ) end
function MOAIParticleSystem.getLoc( ) end
function MOAIParticleSystem.getPiv( ) end
function MOAIParticleSystem.getRect( ) end
function MOAIParticleSystem.getRot( ) end
function MOAIParticleSystem.getScl( ) end
function MOAIParticleSystem.getState( ) end
function MOAIParticleSystem.getWorldDir( ) end
function MOAIParticleSystem.getWorldLoc( ) end
function MOAIParticleSystem.getWorldRot( ) end
function MOAIParticleSystem.getWorldScl( ) end
function MOAIParticleSystem.inside( ) end
function MOAIParticleSystem.modelToWorld( ) end
function MOAIParticleSystem.move( ) end
function MOAIParticleSystem.moveColor( ) end
function MOAIParticleSystem.moveLoc( ) end
function MOAIParticleSystem.movePiv( ) end
function MOAIParticleSystem.moveRot( ) end
function MOAIParticleSystem.moveScl( ) end
function MOAIParticleSystem.pushParticle( ) end
function MOAIParticleSystem.pushSprite( ) end
function MOAIParticleSystem.reserveParticles( ) end
function MOAIParticleSystem.reserveSprites( ) end
function MOAIParticleSystem.reserveStates( ) end
function MOAIParticleSystem.seek( ) end
function MOAIParticleSystem.seekColor( ) end
function MOAIParticleSystem.seekLoc( ) end
function MOAIParticleSystem.seekPiv( ) end
function MOAIParticleSystem.seekRot( ) end
function MOAIParticleSystem.seekScl( ) end
function MOAIParticleSystem.setBlendMode( ) end
function MOAIParticleSystem.setColor( ) end
function MOAIParticleSystem.setDeck( ) end
function MOAIParticleSystem.setExpandForSort( ) end
function MOAIParticleSystem.setFrame( ) end
function MOAIParticleSystem.setGrid( ) end
function MOAIParticleSystem.setGridScale( ) end
function MOAIParticleSystem.setIndex( ) end
function MOAIParticleSystem.setLoc( ) end
function MOAIParticleSystem.setParent( ) end
function MOAIParticleSystem.setPiv( ) end
function MOAIParticleSystem.setRemapper( ) end
function MOAIParticleSystem.setRot( ) end
function MOAIParticleSystem.setScl( ) end
function MOAIParticleSystem.setShader( ) end
function MOAIParticleSystem.setSpriteColor( ) end
function MOAIParticleSystem.setSpriteDeckIdx( ) end
function MOAIParticleSystem.setState( ) end
function MOAIParticleSystem.setUVTransform( ) end
function MOAIParticleSystem.setVisible( ) end
function MOAIParticleSystem.surge( ) end
function MOAIParticleSystem.worldToModel( ) end

-- MOAIParticleTimedEmitter
MOAIParticleTimedEmitter = { }

function MOAIParticleTimedEmitter.addLoc( ) end
function MOAIParticleTimedEmitter.addPiv( ) end
function MOAIParticleTimedEmitter.addRot( ) end
function MOAIParticleTimedEmitter.addScl( ) end
function MOAIParticleTimedEmitter.getLoc( ) end
function MOAIParticleTimedEmitter.getPiv( ) end
function MOAIParticleTimedEmitter.getRot( ) end
function MOAIParticleTimedEmitter.getScl( ) end
function MOAIParticleTimedEmitter.getWorldDir( ) end
function MOAIParticleTimedEmitter.getWorldLoc( ) end
function MOAIParticleTimedEmitter.getWorldRot( ) end
function MOAIParticleTimedEmitter.getWorldScl( ) end
function MOAIParticleTimedEmitter.modelToWorld( ) end
function MOAIParticleTimedEmitter.move( ) end
function MOAIParticleTimedEmitter.moveLoc( ) end
function MOAIParticleTimedEmitter.movePiv( ) end
function MOAIParticleTimedEmitter.moveRot( ) end
function MOAIParticleTimedEmitter.moveScl( ) end
function MOAIParticleTimedEmitter.seek( ) end
function MOAIParticleTimedEmitter.seekLoc( ) end
function MOAIParticleTimedEmitter.seekPiv( ) end
function MOAIParticleTimedEmitter.seekRot( ) end
function MOAIParticleTimedEmitter.seekScl( ) end
function MOAIParticleTimedEmitter.setAngle( ) end
function MOAIParticleTimedEmitter.setEmission( ) end
function MOAIParticleTimedEmitter.setFrequency( ) end
function MOAIParticleTimedEmitter.setLoc( ) end
function MOAIParticleTimedEmitter.setMagnitude( ) end
function MOAIParticleTimedEmitter.setParent( ) end
function MOAIParticleTimedEmitter.setPiv( ) end
function MOAIParticleTimedEmitter.setRadius( ) end
function MOAIParticleTimedEmitter.setRect( ) end
function MOAIParticleTimedEmitter.setRot( ) end
function MOAIParticleTimedEmitter.setScl( ) end
function MOAIParticleTimedEmitter.setSystem( ) end
function MOAIParticleTimedEmitter.surge( ) end
function MOAIParticleTimedEmitter.worldToModel( ) end

-- MOAIPartition
MOAIPartition = { }

function MOAIPartition.clear( ) end
function MOAIPartition.insertProp( ) end
function MOAIPartition.propForPoint( ) end
function MOAIPartition.propListForPoint( ) end
function MOAIPartition.propListForRect( ) end
function MOAIPartition.removeProp( ) end
function MOAIPartition.reserveLayers( ) end
function MOAIPartition.setLayer( ) end
function MOAIPartition.sortedPropListForPoint( ) end
function MOAIPartition.sortedPropListForRect( ) end

-- MOAIPartitionResultBuffer
MOAIPartitionResultBuffer = { }

-- MOAIPathFinder
MOAIPathFinder = { }

function MOAIPathFinder.findPath( ) end
function MOAIPathFinder.getGraph( ) end
function MOAIPathFinder.getPathEntry( ) end
function MOAIPathFinder.getPathSize( ) end
function MOAIPathFinder.init( ) end
function MOAIPathFinder.reserveTerrainWeights( ) end
function MOAIPathFinder.setFlags( ) end
function MOAIPathFinder.setGraph( ) end
function MOAIPathFinder.setHeuristic( ) end
function MOAIPathFinder.setTerrainDeck( ) end
function MOAIPathFinder.setTerrainScale( ) end
function MOAIPathFinder.setWeight( ) end

-- MOAIPathTerrainDeck
MOAIPathTerrainDeck = { }

function MOAIPathTerrainDeck.getMask( ) end
function MOAIPathTerrainDeck.getTerrainVec( ) end
function MOAIPathTerrainDeck.reserve( ) end
function MOAIPathTerrainDeck.setMask( ) end
function MOAIPathTerrainDeck.setTerrainVec( ) end

-- MOAIPointerSensor
MOAIPointerSensor = { }

function MOAIPointerSensor.getLoc( ) end
function MOAIPointerSensor.setCallback( ) end

-- MOAIProp
MOAIProp = { }

function MOAIProp.addLoc( ) end
function MOAIProp.addPiv( ) end
function MOAIProp.addRot( ) end
function MOAIProp.addScl( ) end
function MOAIProp.getLoc( ) end
function MOAIProp.getPiv( ) end
function MOAIProp.getPriority( ) end
function MOAIProp.getRot( ) end
function MOAIProp.getScl( ) end
function MOAIProp.getWorldDir( ) end
function MOAIProp.getWorldLoc( ) end
function MOAIProp.getWorldRot( ) end
function MOAIProp.getWorldScl( ) end
function MOAIProp.modelToWorld( ) end
function MOAIProp.move( ) end
function MOAIProp.moveLoc( ) end
function MOAIProp.movePiv( ) end
function MOAIProp.moveRot( ) end
function MOAIProp.moveScl( ) end
function MOAIProp.seek( ) end
function MOAIProp.seekLoc( ) end
function MOAIProp.seekPiv( ) end
function MOAIProp.seekRot( ) end
function MOAIProp.seekScl( ) end
function MOAIProp.setLoc( ) end
function MOAIProp.setParent( ) end
function MOAIProp.setPiv( ) end
function MOAIProp.setPriority( ) end
function MOAIProp.setRot( ) end
function MOAIProp.setScl( ) end
function MOAIProp.worldToModel( ) end

-- MOAIProp2D
MOAIProp2D = { }
MOAIProp2D.FRAME_FROM_DECK = true
MOAIProp2D.FRAME_FROM_PARENT = true
MOAIProp2D.FRAME_FROM_SELF = true
MOAIProp2D.BLEND_NORMAL = true
MOAIProp2D.BLEND_ADD = true
MOAIProp2D.BLEND_MULTIPLY = true
MOAIProp2D.GL_ONE = true
MOAIProp2D.GL_ZERO = true
MOAIProp2D.GL_DST_ALPHA = true
MOAIProp2D.GL_DST_COLOR = true
MOAIProp2D.GL_SRC_COLOR = true
MOAIProp2D.GL_ONE_MINUS_DST_ALPHA = true
MOAIProp2D.GL_ONE_MINUS_DST_COLOR = true
MOAIProp2D.GL_ONE_MINUS_SRC_ALPHA = true
MOAIProp2D.GL_ONE_MINUS_SRC_COLOR = true
MOAIProp2D.GL_SRC_ALPHA = true
MOAIProp2D.GL_SRC_ALPHA_SATURATE = true
MOAIProp2D.ATTR_INDEX = true

function MOAIProp2D.addLoc( ) end
function MOAIProp2D.addPiv( ) end
function MOAIProp2D.addRot( ) end
function MOAIProp2D.addScl( ) end
function MOAIProp2D.getGrid( ) end
function MOAIProp2D.getIndex( ) end
function MOAIProp2D.getLoc( ) end
function MOAIProp2D.getPiv( ) end
function MOAIProp2D.getRect( ) end
function MOAIProp2D.getRot( ) end
function MOAIProp2D.getScl( ) end
function MOAIProp2D.getWorldDir( ) end
function MOAIProp2D.getWorldLoc( ) end
function MOAIProp2D.getWorldRot( ) end
function MOAIProp2D.getWorldScl( ) end
function MOAIProp2D.inside( ) end
function MOAIProp2D.modelToWorld( ) end
function MOAIProp2D.move( ) end
function MOAIProp2D.moveColor( ) end
function MOAIProp2D.moveLoc( ) end
function MOAIProp2D.movePiv( ) end
function MOAIProp2D.moveRot( ) end
function MOAIProp2D.moveScl( ) end
function MOAIProp2D.seek( ) end
function MOAIProp2D.seekColor( ) end
function MOAIProp2D.seekLoc( ) end
function MOAIProp2D.seekPiv( ) end
function MOAIProp2D.seekRot( ) end
function MOAIProp2D.seekScl( ) end
function MOAIProp2D.setBlendMode( ) end
function MOAIProp2D.setColor( ) end
function MOAIProp2D.setDeck( ) end
function MOAIProp2D.setExpandForSort( ) end
function MOAIProp2D.setFrame( ) end
function MOAIProp2D.setGrid( ) end
function MOAIProp2D.setGridScale( ) end
function MOAIProp2D.setIndex( ) end
function MOAIProp2D.setLoc( ) end
function MOAIProp2D.setParent( ) end
function MOAIProp2D.setPiv( ) end
function MOAIProp2D.setRemapper( ) end
function MOAIProp2D.setRot( ) end
function MOAIProp2D.setScl( ) end
function MOAIProp2D.setShader( ) end
function MOAIProp2D.setUVTransform( ) end
function MOAIProp2D.setVisible( ) end
function MOAIProp2D.worldToModel( ) end

-- MOAIScriptDeck
MOAIScriptDeck = { }

function MOAIScriptDeck.setDrawCallback( ) end
function MOAIScriptDeck.setRect( ) end
function MOAIScriptDeck.setRectCallback( ) end
function MOAIScriptDeck.setShader( ) end

-- MOAIScriptNode
MOAIScriptNode = { }

function MOAIScriptNode.reserveAttrs( ) end
function MOAIScriptNode.setCallback( ) end

-- MOAISensor
MOAISensor = { }

-- MOAISerializer
MOAISerializer = { }

function MOAISerializer.exportToFile( ) end
function MOAISerializer.exportToString( ) end
function MOAISerializer.serialize( ) end
function MOAISerializer.serializeToFile( ) end
function MOAISerializer.serializeToString( ) end

-- MOAIShader
MOAIShader = { }
MOAIShader.UNIFORM_COLOR = true
MOAIShader.UNIFORM_FLOAT = true
MOAIShader.UNIFORM_INT = true
MOAIShader.UNIFORM_PEN_COLOR = true
MOAIShader.UNIFORM_TRANSFORM = true
MOAIShader.UNIFORM_VIEW_PROJ = true
MOAIShader.UNIFORM_WORLD = true
MOAIShader.UNIFORM_WORLD_VIEW_PROJ = true

function MOAIShader.clearUniform( ) end
function MOAIShader.declareUniform( ) end
function MOAIShader.load( ) end
function MOAIShader.reserveUniforms( ) end
function MOAIShader.setVertexAttribute( ) end

-- MOAISim
MOAISim = { }
MOAISim.EVENT_FINALIZE = true

function MOAISim.clearLoopFlags( ) end
function MOAISim.clearRenderStack( ) end
function MOAISim.enterFullscreenMode( ) end
function MOAISim.exitFullscreenMode( ) end
function MOAISim.forceGarbageCollection( ) end
function MOAISim.framesToTime( ) end
function MOAISim.getDeviceSize( ) end
function MOAISim.getDeviceTime( ) end
function MOAISim.getElapsedFrames( ) end
function MOAISim.getElapsedTime( ) end
function MOAISim.getLoopFlags( ) end
function MOAISim.getLuaObjectCount( ) end
function MOAISim.getMemoryUsage( ) end
function MOAISim.getPerformance( ) end
function MOAISim.getStep( ) end
function MOAISim.openWindow( ) end
function MOAISim.pauseTimer( ) end
function MOAISim.popRenderPass( ) end
function MOAISim.pushRenderPass( ) end
function MOAISim.reportHistogram( ) end
function MOAISim.reportLeaks( ) end
function MOAISim.setBoostThreshold( ) end
function MOAISim.setCpuBudget( ) end
function MOAISim.setHistogramEnabled( ) end
function MOAISim.setLeakTrackingEnabled( ) end
function MOAISim.setLongDelayThreshold( ) end
function MOAISim.setLoopFlags( ) end
function MOAISim.setLuaAllocLogEnabled( ) end
function MOAISim.setStep( ) end
function MOAISim.setStepMultiplier( ) end
function MOAISim.setTimerError( ) end
function MOAISim.timeToFrames( ) end

-- MOAIStretchPatch2D
MOAIStretchPatch2D = { }

function MOAIStretchPatch2D.reserveColumns( ) end
function MOAIStretchPatch2D.reserveRows( ) end
function MOAIStretchPatch2D.reserveUVRects( ) end
function MOAIStretchPatch2D.setColumn( ) end
function MOAIStretchPatch2D.setRect( ) end
function MOAIStretchPatch2D.setRow( ) end
function MOAIStretchPatch2D.setShader( ) end
function MOAIStretchPatch2D.setTexture( ) end
function MOAIStretchPatch2D.setUVRect( ) end

-- MOAISurfaceDeck2D
MOAISurfaceDeck2D = { }

function MOAISurfaceDeck2D.reserveSurfaceLists( ) end
function MOAISurfaceDeck2D.reserveSurfaces( ) end
function MOAISurfaceDeck2D.setShader( ) end
function MOAISurfaceDeck2D.setSurface( ) end

-- MOAITapjoy
MOAITapjoy = { }
MOAITapjoy.TAPJOY_VIDEO_AD_BEGIN = true
MOAITapjoy.TAPJOY_VIDEO_AD_CLOSE = true

-- MOAITextBox
MOAITextBox = { }
MOAITextBox.LEFT_JUSTIFY = true
MOAITextBox.CENTER_JUSTIFY = true
MOAITextBox.RIGHT_JUSTIFY = true

function MOAITextBox.addLoc( ) end
function MOAITextBox.addPiv( ) end
function MOAITextBox.addRot( ) end
function MOAITextBox.addScl( ) end
function MOAITextBox.clearCurves( ) end
function MOAITextBox.getGrid( ) end
function MOAITextBox.getIndex( ) end
function MOAITextBox.getLineSize( ) end
function MOAITextBox.getLoc( ) end
function MOAITextBox.getPiv( ) end
function MOAITextBox.getRect( ) end
function MOAITextBox.getRot( ) end
function MOAITextBox.getScl( ) end
function MOAITextBox.getStringBounds( ) end
function MOAITextBox.getWorldDir( ) end
function MOAITextBox.getWorldLoc( ) end
function MOAITextBox.getWorldRot( ) end
function MOAITextBox.getWorldScl( ) end
function MOAITextBox.inside( ) end
function MOAITextBox.modelToWorld( ) end
function MOAITextBox.more( ) end
function MOAITextBox.move( ) end
function MOAITextBox.moveColor( ) end
function MOAITextBox.moveLoc( ) end
function MOAITextBox.movePiv( ) end
function MOAITextBox.moveRot( ) end
function MOAITextBox.moveScl( ) end
function MOAITextBox.nextPage( ) end
function MOAITextBox.reserveCurves( ) end
function MOAITextBox.revealAll( ) end
function MOAITextBox.seek( ) end
function MOAITextBox.seekColor( ) end
function MOAITextBox.seekLoc( ) end
function MOAITextBox.seekPiv( ) end
function MOAITextBox.seekRot( ) end
function MOAITextBox.seekScl( ) end
function MOAITextBox.setAlignment( ) end
function MOAITextBox.setBlendMode( ) end
function MOAITextBox.setColor( ) end
function MOAITextBox.setCurve( ) end
function MOAITextBox.setDeck( ) end
function MOAITextBox.setExpandForSort( ) end
function MOAITextBox.setFont( ) end
function MOAITextBox.setFrame( ) end
function MOAITextBox.setGrid( ) end
function MOAITextBox.setGridScale( ) end
function MOAITextBox.setIndex( ) end
function MOAITextBox.setLineSpacing( ) end
function MOAITextBox.setLoc( ) end
function MOAITextBox.setParent( ) end
function MOAITextBox.setPiv( ) end
function MOAITextBox.setRect( ) end
function MOAITextBox.setRemapper( ) end
function MOAITextBox.setReveal( ) end
function MOAITextBox.setRightToLeft( ) end
function MOAITextBox.setRot( ) end
function MOAITextBox.setScl( ) end
function MOAITextBox.setShader( ) end
function MOAITextBox.setSpeed( ) end
function MOAITextBox.setString( ) end
function MOAITextBox.setStringColor( ) end
function MOAITextBox.setTextSize( ) end
function MOAITextBox.setUVTransform( ) end
function MOAITextBox.setVisible( ) end
function MOAITextBox.setYFlip( ) end
function MOAITextBox.spool( ) end
function MOAITextBox.worldToModel( ) end

-- MOAITexture
MOAITexture = { }
MOAITexture.GL_LINEAR = true
MOAITexture.GL_LINEAR_MIPMAP_LINEAR = true
MOAITexture.GL_LINEAR_MIPMAP_NEAREST = true
MOAITexture.GL_NEAREST = true
MOAITexture.GL_NEAREST_MIPMAP_LINEAR = true
MOAITexture.GL_NEAREST_MIPMAP_NEAREST = true

function MOAITexture.bind( ) end
function MOAITexture.getSize( ) end
function MOAITexture.initFrameBuffer( ) end
function MOAITexture.load( ) end
function MOAITexture.release( ) end
function MOAITexture.setFilter( ) end
function MOAITexture.setWrap( ) end

-- MOAITileDeck2D
MOAITileDeck2D = { }

function MOAITileDeck2D.cellAddrToCoord( ) end
function MOAITileDeck2D.getCellAddr( ) end
function MOAITileDeck2D.getCellSize( ) end
function MOAITileDeck2D.getOffset( ) end
function MOAITileDeck2D.getSize( ) end
function MOAITileDeck2D.getTileLoc( ) end
function MOAITileDeck2D.getTileSize( ) end
function MOAITileDeck2D.initDiamondGrid( ) end
function MOAITileDeck2D.initHexGrid( ) end
function MOAITileDeck2D.initObliqueGrid( ) end
function MOAITileDeck2D.initRectGrid( ) end
function MOAITileDeck2D.locToCellAddr( ) end
function MOAITileDeck2D.locToCoord( ) end
function MOAITileDeck2D.setRect( ) end
function MOAITileDeck2D.setRepeat( ) end
function MOAITileDeck2D.setShader( ) end
function MOAITileDeck2D.setShape( ) end
function MOAITileDeck2D.setSize( ) end
function MOAITileDeck2D.setTexture( ) end
function MOAITileDeck2D.wrapCoord( ) end

-- MOAITimer
MOAITimer = { }
MOAITimer.NORMAL = true
MOAITimer.REVERSE = true
MOAITimer.LOOP = true
MOAITimer.LOOP_REVERSE = true
MOAITimer.PING_PONG = true
MOAITimer.EVENT_TIMER_KEYFRAME = true
MOAITimer.EVENT_TIMER_LOOP = true
MOAITimer.ATTR_TIME = true

function MOAITimer.getTime( ) end
function MOAITimer.getTimesExecuted( ) end
function MOAITimer.setCurve( ) end
function MOAITimer.setMode( ) end
function MOAITimer.setSpan( ) end
function MOAITimer.setSpeed( ) end
function MOAITimer.setTime( ) end

-- MOAITouchSensor
MOAITouchSensor = { }
MOAITouchSensor.TOUCH_DOWN = true
MOAITouchSensor.TOUCH_MOVE = true
MOAITouchSensor.TOUCH_UP = true
MOAITouchSensor.TOUCH_CANCEL = true

function MOAITouchSensor.down( ) end
function MOAITouchSensor.getActiveTouches( ) end
function MOAITouchSensor.getTouch( ) end
function MOAITouchSensor.hasTouches( ) end
function MOAITouchSensor.isDown( ) end
function MOAITouchSensor.setCallback( ) end
function MOAITouchSensor.up( ) end

-- MOAITransform
MOAITransform = { }
MOAITransform.ATTR_X_PIV = true
MOAITransform.ATTR_Y_PIV = true
MOAITransform.ATTR_X_LOC = true
MOAITransform.ATTR_Y_LOC = true
MOAITransform.ATTR_Z_ROT = true
MOAITransform.ATTR_X_SCL = true
MOAITransform.ATTR_Y_SCL = true

function MOAITransform.addLoc( ) end
function MOAITransform.addPiv( ) end
function MOAITransform.addRot( ) end
function MOAITransform.addScl( ) end
function MOAITransform.getLoc( ) end
function MOAITransform.getPiv( ) end
function MOAITransform.getRot( ) end
function MOAITransform.getScl( ) end
function MOAITransform.getWorldDir( ) end
function MOAITransform.getWorldLoc( ) end
function MOAITransform.getWorldRot( ) end
function MOAITransform.getWorldScl( ) end
function MOAITransform.modelToWorld( ) end
function MOAITransform.move( ) end
function MOAITransform.moveLoc( ) end
function MOAITransform.movePiv( ) end
function MOAITransform.moveRot( ) end
function MOAITransform.moveScl( ) end
function MOAITransform.seek( ) end
function MOAITransform.seekLoc( ) end
function MOAITransform.seekPiv( ) end
function MOAITransform.seekRot( ) end
function MOAITransform.seekScl( ) end
function MOAITransform.setLoc( ) end
function MOAITransform.setParent( ) end
function MOAITransform.setPiv( ) end
function MOAITransform.setRot( ) end
function MOAITransform.setScl( ) end
function MOAITransform.worldToModel( ) end

-- MOAITransformBase
MOAITransformBase = { }
MOAITransformBase.ATTR_WORLD_X_LOC = true
MOAITransformBase.ATTR_WORLD_Y_LOC = true
MOAITransformBase.ATTR_WORLD_Z_ROT = true
MOAITransformBase.ATTR_WORLD_X_SCL = true
MOAITransformBase.ATTR_WORLD_Y_SCL = true

function MOAITransformBase.getWorldDir( ) end
function MOAITransformBase.getWorldLoc( ) end
function MOAITransformBase.getWorldRot( ) end
function MOAITransformBase.getWorldScl( ) end

-- MOAIUntzSampleBuffer
MOAIUntzSampleBuffer = { }

function MOAIUntzSampleBuffer.load( ) end

-- MOAIUntzSound
MOAIUntzSound = { }
MOAIUntzSound.ATTR_VOLUME = true

function MOAIUntzSound.getPosition( ) end
function MOAIUntzSound.getVolume( ) end
function MOAIUntzSound.isLooping( ) end
function MOAIUntzSound.isPaused( ) end
function MOAIUntzSound.isPlaying( ) end
function MOAIUntzSound.load( ) end
function MOAIUntzSound.moveVolume( ) end
function MOAIUntzSound.pause( ) end
function MOAIUntzSound.play( ) end
function MOAIUntzSound.seekVolume( ) end
function MOAIUntzSound.setLooping( ) end
function MOAIUntzSound.setLoopPoints( ) end
function MOAIUntzSound.setPosition( ) end
function MOAIUntzSound.setVolume( ) end
function MOAIUntzSound.stop( ) end

-- MOAIUntzSystem
MOAIUntzSystem = { }

function MOAIUntzSystem.getSampleRate( ) end
function MOAIUntzSystem.getVolume( ) end
function MOAIUntzSystem.initialize( ) end
function MOAIUntzSystem.setSampleRate( ) end
function MOAIUntzSystem.setVolume( ) end

-- MOAIVertexBuffer
MOAIVertexBuffer = { }
MOAIVertexBuffer.GL_POINTS = true
MOAIVertexBuffer.GL_LINES = true
MOAIVertexBuffer.GL_TRIANGLES = true
MOAIVertexBuffer.GL_LINE_LOOP = true
MOAIVertexBuffer.GL_LINE_STRIP = true
MOAIVertexBuffer.GL_TRIANGLE_FAN = true
MOAIVertexBuffer.GL_TRIANGLE_STRIP = true

function MOAIVertexBuffer.bless( ) end
function MOAIVertexBuffer.release( ) end
function MOAIVertexBuffer.reserve( ) end
function MOAIVertexBuffer.reserveVerts( ) end
function MOAIVertexBuffer.reset( ) end
function MOAIVertexBuffer.setFormat( ) end
function MOAIVertexBuffer.setPenWidth( ) end
function MOAIVertexBuffer.setPointSize( ) end
function MOAIVertexBuffer.setPrimType( ) end
function MOAIVertexBuffer.writeColor32( ) end
function MOAIVertexBuffer.writeFloat( ) end
function MOAIVertexBuffer.writeInt16( ) end
function MOAIVertexBuffer.writeInt32( ) end
function MOAIVertexBuffer.writeInt8( ) end

-- MOAIVertexFormat
MOAIVertexFormat = { }

function MOAIVertexFormat.declareAttribute( ) end
function MOAIVertexFormat.declareColor( ) end
function MOAIVertexFormat.declareCoord( ) end
function MOAIVertexFormat.declareNormal( ) end
function MOAIVertexFormat.declareUV( ) end

-- MOAIViewport
MOAIViewport = { }

function MOAIViewport.setOffset( ) end
function MOAIViewport.setRotation( ) end
function MOAIViewport.setScale( ) end
function MOAIViewport.setSize( ) end

-- MOAIWheelSensor
MOAIWheelSensor = { }

function MOAIWheelSensor.getDelta( ) end
function MOAIWheelSensor.getValue( ) end
function MOAIWheelSensor.setCallback( ) end

-- MOAIXmlParser
MOAIXmlParser = { }

function MOAIXmlParser.parseFile( ) end
function MOAIXmlParser.parseString( ) end

